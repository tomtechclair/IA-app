const weatherDatabase = {};

const API_CONFIG = {
    weatherUrl: 'https://api.openweathermap.org/data/2.5/weather',
    forecastUrl: 'https://api.openweathermap.org/data/2.5/forecast',
    geoUrl: 'https://geocoding-api.open-meteo.com/v1',
    apiKey: 'bd5e37850363998ee72118a6233cdd38' // Clé API OpenWeatherMap valide
};

let currentCity = 'Paris';
let currentCoords = { lat: 48.8566, lon: 2.3522 };

const cities = [
    'Paris', 'Lyon', 'Marseille', 'Toulouse', 'Nice', 'Nantes', 'Strasbourg',
    'Montpellier', 'Bordeaux', 'Lille', 'Rennes', 'Reims', 'Le Havre', 'Saint-Étienne',
    'Toulon', 'Grenoble', 'Dijon', 'Angers', 'Nîmes', 'Villeurbanne', 'Clermont-Ferrand',
    'Le Mans', 'Aix-en-Provence', 'Brest', 'Limoges', 'Tours', 'Amiens', 'Metz',
    'Perpignan', 'Boulogne-Billancourt', 'Mulhouse', 'Rouen', 'Caen', 'Nancy',
    'Saint-Denis', 'Roubaix', 'Tourcoing', 'Argenteuil', 'Dunkerque', 'Créteil',
    'Poitiers', 'Versailles', 'Courbevoie', 'Nanterre', 'Avignon', 'Colmar'
];

const weatherCodes = {
    0: { condition: 'Ensoleillé', bg: 'bg-blue' },
    1: { condition: 'Partiellement nuageux', bg: 'bg-blue' },
    2: { condition: 'Nuageux', bg: 'bg-cloudy' },
    3: { condition: 'Couvert', bg: 'bg-cloudy' },
    45: { condition: 'Brouillard', bg: 'bg-cloudy' },
    48: { condition: 'Brouillard givrant', bg: 'bg-cloudy' },
    51: { condition: 'Bruine légère', bg: 'bg-rain' },
    53: { condition: 'Bruine modérée', bg: 'bg-rain' },
    55: { condition: 'Bruine forte', bg: 'bg-rain' },
    61: { condition: 'Pluie légère', bg: 'bg-rain' },
    63: { condition: 'Pluie modérée', bg: 'bg-rain' },
    65: { condition: 'Pluie forte', bg: 'bg-rain' },
    71: { condition: 'Neige légère', bg: 'bg-cloudy' },
    73: { condition: 'Neige modérée', bg: 'bg-cloudy' },
    75: { condition: 'Neige forte', bg: 'bg-cloudy' },
    77: { condition: 'Grains de neige', bg: 'bg-cloudy' },
    80: { condition: 'Averses légères', bg: 'bg-rain' },
    81: { condition: 'Averses modérées', bg: 'bg-rain' },
    82: { condition: 'Averses violentes', bg: 'bg-rain' },
    85: { condition: 'Averses de neige', bg: 'bg-cloudy' },
    86: { condition: 'Averses de neige', bg: 'bg-cloudy' },
    95: { condition: 'Orage', bg: 'bg-rain' },
    96: { condition: 'Orage grêle', bg: 'bg-rain' },
    99: { condition: 'Orage violent', bg: 'bg-rain' }
};

const days = ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam'];

function getWeatherInfo(code) {
    return weatherCodes[code] || { condition: 'Inconnu', bg: 'bg-blue' };
}

async function searchCityCoords(cityName) {
    try {
        const geoUrl = `https://api.openweathermap.org/geo/1.0/direct?q=${encodeURIComponent(cityName)}&limit=5&appid=${API_CONFIG.apiKey}`;
        const response = await fetch(geoUrl);
        const data = await response.json();
        
        if (data && data.length > 0) {
            const result = data[0];
            return {
                name: result.name || cityName,
                lat: result.lat,
                lon: result.lon,
                country: result.country || '',
                state: result.state || ''
            };
        }
        return null;
    } catch (error) {
        console.error('Erreur de géocoding:', error);
        return null;
    }
}

async function fetchWeatherData(lat, lon) {
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 10000);

        const weatherUrl = `${API_CONFIG.weatherUrl}?lat=${lat}&lon=${lon}&appid=${API_CONFIG.apiKey}&units=metric&lang=fr`;
        const forecastUrl = `${API_CONFIG.forecastUrl}?lat=${lat}&lon=${lon}&appid=${API_CONFIG.apiKey}&units=metric&lang=fr`;

        const [weatherResponse, forecastResponse] = await Promise.all([
            fetch(weatherUrl, { signal: controller.signal }),
            fetch(forecastUrl, { signal: controller.signal })
        ]);

        clearTimeout(timeoutId);

        if (!weatherResponse.ok || !forecastResponse.ok) {
            throw new Error('Erreur API');
        }

        const weatherData = await weatherResponse.json();
        const forecastData = await forecastResponse.json();

        return {
            current: {
                temperature_2m: Math.round(weatherData.main.temp),
                relative_humidity_2m: weatherData.main.humidity,
                apparent_temperature: Math.round(weatherData.main.feels_like),
                is_day: (Date.now() / 1000 >= weatherData.sys.sunrise && Date.now() / 1000 <= weatherData.sys.sunset) ? 1 : 0,
                weather_code: getWeatherCodeFromOpenWeather(weatherData.weather[0].id),
                wind_speed_10m: Math.round(weatherData.wind.speed * 3.6),
                pressure_msl: weatherData.main.pressure,
                visibility: weatherData.visibility,
                sunrise: weatherData.sys.sunrise * 1000,
                sunset: weatherData.sys.sunset * 1000
            },
            hourly: {
                time: forecastData.list.slice(0, 24).map(item => item.dt * 1000),
                temperature_2m: forecastData.list.slice(0, 24).map(item => Math.round(item.main.temp)),
                weather_code: forecastData.list.slice(0, 24).map(item => getWeatherCodeFromOpenWeather(item.weather[0].id)),
                is_day: forecastData.list.slice(0, 24).map(item => (item.dt >= weatherData.sys.sunrise && item.dt <= weatherData.sys.sunset) ? 1 : 0)
            },
            daily: {
                time: forecastData.list.filter((_, index) => index % 8 === 0).map(item => item.dt * 1000),
                temperature_2m_max: forecastData.list.filter((_, index) => index % 8 === 0).map(item => Math.round(item.main.temp_max)),
                temperature_2m_min: forecastData.list.filter((_, index) => index % 8 === 0).map(item => Math.round(item.main.temp_min)),
                weather_code: forecastData.list.filter((_, index) => index % 8 === 0).map(item => getWeatherCodeFromOpenWeather(item.weather[0].id)),
                sunrise: [weatherData.sys.sunrise * 1000],
                sunset: [weatherData.sys.sunset * 1000]
            }
        };
    } catch (error) {
        console.error('Erreur fetch:', error);
        return null;
    }
}

function getWeatherCodeFromOpenWeather(id) {
    if (id >= 200 && id < 300) return 95; // Orage
    if (id >= 300 && id < 400) return 51; // Bruine
    if (id >= 500 && id < 600) return 61; // Pluie
    if (id >= 600 && id < 700) return 71; // Neige
    if (id >= 700 && id < 800) return 45; // Brouillard
    if (id === 800) return 0; // Dégagé
    if (id === 801) return 1; // Partiellement nuageux
    if (id === 802) return 2; // Nuageux
    if (id > 802) return 3; // Couvert
    return 0;
}

async function updateWeather(cityName) {
    const cityData = await searchCityCoords(cityName);
    if (!cityData) return;
    
    currentCity = cityData.name;
    const weatherData = await fetchWeatherData(cityData.lat, cityData.lon);
    if (weatherData) displayWeatherData(weatherData);
}

function displayWeatherData(weatherData) {
    const current = weatherData.current;
    const weatherInfo = getWeatherInfo(current.weather_code);
    
    document.querySelector('.city').textContent = currentCity;
    document.querySelector('.big-temp').textContent = `${current.temperature_2m}°`;
    document.querySelector('.condition').textContent = weatherInfo.condition;
    
    document.querySelector('.high-low').innerHTML = 
        `<span>H:${weatherData.daily.temperature_2m_max[0]}°</span>` +
        `<span>L:${weatherData.daily.temperature_2m_min[0]}°</span>`;
        
    document.getElementById('humidity').textContent = `${current.relative_humidity_2m}%`;
    document.getElementById('wind').innerHTML = `${current.wind_speed_10m} <span class="unit">km/h</span>`;
    document.getElementById('feels-like').textContent = `${current.apparent_temperature}°`;
    
    const details = document.querySelectorAll('.detail-big');
    details[2].innerHTML = `${Math.round(current.visibility / 1000)} <span class="unit">km</span>`;
    details[5].innerHTML = `${current.pressure_msl} <span class="unit">hPa</span>`;
    
    document.getElementById('sunrise').textContent = new Date(current.sunrise).toLocaleTimeString('fr-FR', {hour:'2-digit', minute:'2-digit'});
    document.getElementById('sunset').textContent = new Date(current.sunset).toLocaleTimeString('fr-FR', {hour:'2-digit', minute:'2-digit'});

    // Hourly
    const hourlyList = document.getElementById('hourly-list');
    hourlyList.innerHTML = weatherData.hourly.time.map((time, i) => `
        <div class="hourly-item">
            <div class="time">${i === 0 ? 'Maintenant' : new Date(time).getHours() + 'h'}</div>
            <div class="icon">${typeof createWeatherIconSVG === 'function' ? createWeatherIconSVG(weatherData.hourly.weather_code[i], weatherData.hourly.is_day[i] === 1, 28) : ''}</div>
            <div class="temp">${weatherData.hourly.temperature_2m[i]}°</div>
        </div>
    `).join('');

    // Daily
    const dailyList = document.getElementById('daily-list');
    dailyList.innerHTML = weatherData.daily.time.map((time, i) => `
        <div class="daily-item">
            <div class="day">${i === 0 ? 'Auj.' : days[new Date(time).getDay()]}</div>
            <div class="icon">${typeof createWeatherIconSVG === 'function' ? createWeatherIconSVG(weatherData.daily.weather_code[i], true, 28) : ''}</div>
            <div class="temp-low">${weatherData.daily.temperature_2m_min[i]}°</div>
            <div class="temp-bar-container"><div class="temp-bar" style="width:100%"></div></div>
            <div class="temp-high">${weatherData.daily.temperature_2m_max[i]}°</div>
        </div>
    `).join('');

    updateBackground(current.weather_code, current.is_day === 1);
}

function updateBackground(code, isDay) {
    const bg = document.querySelector('.bg-layer');
    if (code === 0) bg.style.background = isDay ? 'linear-gradient(135deg, #00BFFF 0%, #87CEEB 100%)' : 'linear-gradient(135deg, #191970 0%, #000080 100%)';
    else if (code <= 3) bg.style.background = 'linear-gradient(135deg, #708090 0%, #A9A9A9 100%)';
    else bg.style.background = 'linear-gradient(135deg, #4682B4 0%, #708090 100%)';
}

function setupSearchListeners() {
    const input = document.getElementById('city-input');
    input.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            updateWeather(input.value);
            input.blur();
        }
    });
}

document.addEventListener('DOMContentLoaded', () => {
    setupSearchListeners();
    updateWeather('Paris');
});
