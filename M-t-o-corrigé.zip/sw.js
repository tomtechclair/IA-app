const CACHE_NAME = 'mteo-v2';
const STATIC_RESOURCES = [
    '/',
    '/index.html',
    '/style.css',
    '/weather-icons.css',
    '/weather-icons.js',
    '/script.js',
    '/apple-weather-icons.js',
    '/enhanced-icons.js',
    '/enhanced-weather-icons.js',
    '/init-icons.js'
];

self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open(CACHE_NAME).then((cache) => {
            return cache.addAll(STATIC_RESOURCES);
        })
    );
});

self.addEventListener('activate', (event) => {
    event.waitUntil(
        caches.keys().then((cacheNames) => {
            return Promise.all(
                cacheNames.map((cacheName) => {
                    if (cacheName !== CACHE_NAME) {
                        return caches.delete(cacheName);
                    }
                })
            );
        })
    );
});

self.addEventListener('fetch', (event) => {
    event.respondWith(
        caches.match(event.request).then((response) => {
            return response || fetch(event.request);
        })
    );
});
